/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package étudiant;

import javax.swing.ImageIcon;

/**
 *
 * @author user
 */
public class carte {
    private ImageIcon Image;
    private String id,nom,prenom, date, faculté, fillère,année;
//declaration de tout les element
  public carte() {
         this("", "", "", "","","","", "");
     }
  
  public carte(String id,String nom,String prenom,String date, String faculté,  String fillère,String année, ImageIcon Image){
    this.id=id;
    this.nom = nom;
    this.prenom=prenom;
    this.date=date;
    this.faculté=faculté;
    this.fillère=fillère;
    this.année=année;
    this.Image=Image;
  }

    private carte(String string, String string0, String string1, String string2, String string3, String string4, String string5, String string6) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   public String toString() {
         String resultat = "Aucune information !";

          if (!("".equals(this.nom) &&"".equals(this.prenom) &&"".equals(this.date) && "".equals(this.faculté) &&"".equals(this.fillère) && "".equals(this.année)&&"".equals(this.nom) )) {

             resultat = "id:" +this.id+"\n";
             resultat += "Nom : " + this.nom + "\n";
             resultat += "Prenom : " + this.prenom + "\n";
             resultat += "Date de naissence : " + this.date + "\n";
             resultat += "Faculté : " + this.faculté + "\n";
             resultat += "Fillère : " + this.fillère + "\n";
             resultat += "Année : " + this.année + "\n";
             resultat += this.Image + "\n";

         }
         return resultat;
     }

   
}  

